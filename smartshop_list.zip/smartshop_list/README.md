# SmartShop List v2.0 - Enterprise Edition

Aplicación Flutter de gestión de compras con arquitectura Clean, base de datos NoSQL local y motor heurístico de sugerencias.

## Instalación
1. `flutter pub get`
2. `dart run build_runner build --delete-conflicting-outputs`
3. `flutter run`
